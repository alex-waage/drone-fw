from kafka import KafkaProducer
import os
import logging
logging.basicConfig(level=logging.INFO)

p = KafkaProducer(bootstrap_servers='127.0.0.1:29092', linger_ms=10)
p.send('topic1', b'some_message_bytes')
p.flush()
#r = p.send(topic = 'my_kafka_topic', value = 'message from docker', key = 'docker1')
#print(r.succeeded())