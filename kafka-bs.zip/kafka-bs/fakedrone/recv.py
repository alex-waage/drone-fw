from kafka import KafkaConsumer, TopicPartition

consumer = KafkaConsumer(bootstrap_servers="127.0.0.1:29092", group_id='None')
tp = TopicPartition("test", 0)
consumer.assign([tp])
consumer.seek_to_beginning()
print("receiving messages")

while True:
    for msg in consumer:
        print(msg.value)