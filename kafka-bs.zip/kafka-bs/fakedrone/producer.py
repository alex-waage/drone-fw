from kafka import KafkaProducer
producer = KafkaProducer(bootstrap_servers = 'ptommy.com:29092')

while True:
	print("\n\nType \"quit\" to exit")
	print("Enter message to be sent:")
	msg = input()
	if msg == "quit":
		print("Exiting...")
		break
	producer.send('topic1',value=msg.encode('utf-8'))
	print("Sending msg \"{}\"".format(msg))
	print("Message sent!")