const { Kafka } = require('kafkajs');

 dataObj = {
    message: ""
};

const kafka = new Kafka({
  clientId: 'server-backend',
  brokers: ['kafka:9092'],
  retry: {
    initialRetryTime: 1000,
    retries: 20
  }
})

// Consumer code
const consumer = kafka.consumer({ groupId: 'test-group' })
consumer.connect()
consumer.subscribe({ topic: 'topic1', fromBeginning: false, autoCommit: true })

consumer.run({
  eachMessage: async ({ topic, partition, message }) => {
    console.log({
      value: message.value.toString(),
    });
    dataObj.message = message;
  },
})


// Producer code
const producer = kafka.producer({ allowAutoTopicCreation: true })
producer.connect()




module.exports = {
    dataObj,
    consumer,
    producer
};