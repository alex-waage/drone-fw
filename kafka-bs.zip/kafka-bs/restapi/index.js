const express = require('express');
const app = express();

const api = require('./apiRouter.js');

app.use('/api', api)

app.all('*', (req, res) => {
  console.log(req.url);
  res.status(404).json({ error: 'Not Found!' })
})

// Start server
app.listen(process.env.PORT, () => console.log(`listening at port ${process.env.PORT}`));