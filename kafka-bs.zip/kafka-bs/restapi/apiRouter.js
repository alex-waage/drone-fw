const express = require('express')

const { getLatest, getRange, putSpeed, putRotation } = require('./apiFunctions.js')

const router = express.Router()

router.get('/latest', getLatest)
router.get('/range/:beg/:end', getRange)
router.put('/speed/:x/:y/:z', putSpeed)
router.put('/rotation/:rot', putRotation)

module.exports = router