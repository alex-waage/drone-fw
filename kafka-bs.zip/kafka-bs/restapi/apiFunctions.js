const { dataObj, consumer, producer } = require('./kafkaInterface.js')

const getLatest = (req, res) => 
{
    console.log("latest");
    console.log(req.query.param);
    res.status(200).json({status: "success", returnData: dataObj.message});
};

const getRange = (req, res) => 
{
    consumer.seek({topic: "topic1", partition: 0, offset: 0}) // TODO : Get earliest offset
    console.log("range");
    res.status(200).json({status: "success", returnData: null});
};

const putSpeed = (req, res) => 
{
    console.log("speed");
    console.log(req.params.x);
    console.log(req.params.y);
    console.log(req.params.z);
    res.status(200).json({status: "success"});
};

const putRotation = (req, res) => 
{
    console.log("rotation");
    console.log(req.params.rot);
    res.status(200).json({status: "success"});
};

module.exports = {
    getLatest,
    getRange,
    putSpeed,
    putRotation,
}